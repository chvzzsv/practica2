﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica2UI.Forms
{
    public partial class practica2 : Form
    {
        //inicialice un arreglo...
        private Color[] colors = {
            Color.Black,
            Color.Red,
            Color.Blue,
            Color.Green,
            Color.Yellow
        };
        //creacion de variable...
        private int indice = 0;


        public practica2()
        {
            InitializeComponent();
            cambiarColor();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //tomar etiqueta y asignarle un cambio al contenido mediante el evento click del boton...
            label1.Text = "Despues del evento";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //tomar etiqueta y asignarle un cambio al contenido mediante el evento click del boton...
            label1.Text = "Antes del evento";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // genera un color aleatorio utilizando la propiedad FromArgb...
            // cambia el color de fondo del panel de nuestro formulario...

            //panel1.BackColor = Color.FromArgb(255, new Random().Next(255), new Random().Next(255), new Random().Next(256));

            Random random = new Random();
            Color newColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
            panel1.BackColor = newColor;
        }
        //cree una función para cambiar los colores...
        private void cambiarColor()
        {
            pictureBox1.BackColor = colors[indice];
        }

        private void button4_Click(object sender, EventArgs e)
        { //el indice es de donde nos ubicamos en los colores...
          //- 1: Resta 1 al índice actual para retroceder al color anterior.
          //+colors.Length: Agrega la longitud del arreglo de colores al índice.
          //esto se hace para manejar casos donde el índice resultante es negativo.
          //sumar la longitud del arreglo asegura que el resultado final sea un índice positivo o cero.
          //el modulo % calcula el residuo de la división del resultado por la longitud del arreglo de colores.
          //esto asegura que el índice se mantenga dentro de los límites válidos del arreglo.
            indice = (indice + 1 + colors.Length) % colors.Length;
            cambiarColor();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            indice = (indice + 4 + colors.Length) % colors.Length;
            cambiarColor();
        }
    }
}